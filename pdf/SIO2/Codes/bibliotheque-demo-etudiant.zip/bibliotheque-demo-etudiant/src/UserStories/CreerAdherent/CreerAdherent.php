<?php

namespace App\UserStories\CreerAdherent;


class CreerAdherent
{
    public function execute(PARAMETRES) :  bool {

        // Valider les données en entrées (de la requête)

        // Vérifier que l'email n'existe pas déjà

        // Générer un numéro d'adhérent au format AD-999999

        // Vérifier que le numéro n'existe pas déjà

        // Créer l'adhérent

        // Enregistrer l'adhérent en base de données

        return true;
    }
}