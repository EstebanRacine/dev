<?php

namespace App\Services;

class GenerateurNumeroAdherent
{
    public function generer(): string
    {
        return '';
    }
}